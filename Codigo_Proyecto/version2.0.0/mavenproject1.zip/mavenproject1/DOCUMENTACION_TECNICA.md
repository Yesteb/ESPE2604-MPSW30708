# Documentación Técnica Completa — Sistema PinkyPuff

> **Destinatario:** Desarrolladores sin experiencia previa en las tecnologías utilizadas.
> Este documento explica **qué es**, **para qué sirve** y **cómo funciona** cada pieza del sistema.

---

## Tabla de contenidos

1. [Visión general del sistema](#1-visión-general-del-sistema)
2. [Estructura de carpetas](#2-estructura-de-carpetas)
3. [Tecnologías utilizadas](#3-tecnologías-utilizadas)
   - 3.1 Java 21
   - 3.2 Maven
   - 3.3 Lombok
   - 3.4 JPA / Jakarta Persistence
   - 3.5 Hibernate ORM
   - 3.6 PostgreSQL
   - 3.7 OpenPDF (LibrePDF)
   - 3.8 Java Swing
4. [Archivo de configuración pom.xml](#4-archivo-de-configuración-pomxml)
5. [Archivo persistence.xml — La conexión a la base de datos](#5-archivo-persistencexml--la-conexión-a-la-base-de-datos)
   - 5.1 Cómo agregar una nueva entidad al persistence.xml
   - 5.2 Qué es `hibernate.hbm2ddl.auto = update`
6. [Capa de Modelo — Las entidades JPA](#6-capa-de-modelo--las-entidades-jpa)
   - 6.1 Administrador
   - 6.2 Cliente
   - 6.3 Pedido
   - 6.4 Producto
   - 6.5 EtiquetaConfig
   - 6.6 Relaciones entre entidades
7. [Capa de Persistencia — Repositorios y Controladores JPA](#7-capa-de-persistencia--repositorios-y-controladores-jpa)
   - 7.1 JPAUtil — El singleton de conexión
   - 7.2 Interfaces Repositorio
   - 7.3 Controladores JPA (implementaciones)
8. [Capa de Servicio — La lógica de negocio](#8-capa-de-servicio--la-lógica-de-negocio)
9. [Patrones de diseño implementados](#9-patrones-de-diseño-implementados)
   - 9.1 MVC (Modelo–Vista–Controlador)
   - 9.2 Patrón Observer (Observador)
   - 9.3 Patrón Repository (Repositorio)
   - 9.4 Singleton
10. [Capa de Vista — Interfaz gráfica con Swing](#10-capa-de-vista--interfaz-gráfica-con-swing)
    - 10.1 FrmLogin — Formulario de acceso
    - 10.2 FrmDashboard — Panel principal
    - 10.3 Archivos .form de NetBeans
11. [Capa de Controlador — Los controladores de UI](#11-capa-de-controlador--los-controladores-de-ui)
    - 11.1 ControladorFrmLogin
    - 11.2 ControladorDashboard
    - 11.3 ControladorTabPedidos
    - 11.4 PlaceholderController
    - 11.5 SistemaAutenticacion
    - 11.6 ReportePDF
12. [Utilidades del sistema](#12-utilidades-del-sistema)
    - 12.1 EstiloUI — Estilos y componentes visuales
    - 12.2 HashContrasena — Seguridad de contraseñas
    - 12.3 CrearAdministradorPrueba
    - 12.4 configuraciones.xml
13. [Esquema de la base de datos](#13-esquema-de-la-base-de-datos)
14. [Cómo ver las tablas en Windows con Docker](#14-cómo-ver-las-tablas-en-windows-con-docker)
15. [Cómo cambiar estilos visuales de los componentes](#15-cómo-cambiar-estilos-visuales-de-los-componentes)
16. [Flujo completo de ejecución](#16-flujo-completo-de-ejecución)
17. [Guía de modificaciones frecuentes](#17-guía-de-modificaciones-frecuentes)

---

## 1. Visión general del sistema

**PinkyPuff** es una aplicación de escritorio desarrollada en Java para gestionar pedidos de una tienda de ropa o accesorios. Permite:

- Iniciar sesión como administrador.
- Registrar productos asociados a clientes y pedidos.
- Ver, filtrar y cambiar el estado de los pedidos (Pendiente / Cobrado / Cancelado).
- Gestionar clientes y su estado (Activo / Inactivo / Bloqueado).
- Configurar etiquetas (tipos, estilos, tallas, precios rápidos) de forma dinámica.
- Exportar reportes y tickets individuales en formato PDF.

La aplicación se conecta a una base de datos **PostgreSQL** (que puede correr en Docker) y usa **Hibernate/JPA** para mapear objetos Java a tablas de base de datos.

---

## 2. Estructura de carpetas

```
mavenproject1/
├── pom.xml                          ← Archivo de configuración de Maven (dependencias)
├── schema.sql                       ← Script SQL para crear las tablas manualmente
├── src/
│   └── main/
│       ├── java/
│       │   ├── model/               ← Entidades JPA (tablas de la base de datos)
│       │   │   ├── Administrador.java
│       │   │   ├── Cliente.java
│       │   │   ├── Pedido.java
│       │   │   ├── Producto.java
│       │   │   └── EtiquetaConfig.java
│       │   ├── persistencia/        ← Acceso a la base de datos (CRUD)
│       │   │   ├── JPAUtil.java
│       │   │   ├── RepositorioCliente.java      (interfaz)
│       │   │   ├── ClienteJpaController.java    (implementación)
│       │   │   ├── RepositorioPedido.java
│       │   │   ├── PedidoJpaController.java
│       │   │   ├── RepositorioProducto.java
│       │   │   ├── ProductoJpaController.java
│       │   │   ├── RepositorioEtiqueta.java
│       │   │   ├── EtiquetaConfigJpaController.java
│       │   │   ├── RepositorioAdministrador.java
│       │   │   ├── AdministradorJpaController.java
│       │   │   └── exceptions/      ← Excepciones personalizadas
│       │   ├── service/             ← Lógica de negocio
│       │   │   ├── PedidoService.java
│       │   │   ├── ObservadorDatos.java
│       │   │   └── SujetoDatos.java
│       │   ├── controller/          ← Controladores de la interfaz gráfica
│       │   │   ├── ControladorFrmLogin.java
│       │   │   ├── ControladorDashboard.java
│       │   │   ├── ControladorTabPedidos.java
│       │   │   ├── PlaceholderController.java
│       │   │   ├── SistemaAutenticacion.java
│       │   │   └── ReportePDF.java
│       │   ├── view/                ← Ventanas/formularios visuales
│       │   │   ├── FrmLogin.java    ← Ventana de inicio de sesión
│       │   │   ├── FrmLogin.form    ← Diseño visual editable en NetBeans
│       │   │   ├── FrmDashboard.java
│       │   │   └── FrmDashboard.form
│       │   └── utils/               ← Clases de apoyo
│       │       ├── EstiloUI.java
│       │       ├── HashContrasena.java
│       │       ├── CrearAdministradorPrueba.java
│       │       └── configuraciones.xml
│       └── resources/
│           └── META-INF/
│               └── persistence.xml  ← Configuración de conexión JPA
└── target/                          ← Archivos compilados (generados automáticamente)
```

---

## 3. Tecnologías utilizadas

### 3.1 Java 21

**¿Qué es?** Java es el lenguaje de programación en el que está escrito todo el sistema.

**¿Por qué Java 21?** Es una versión Long-Term Support (LTS), lo que significa soporte extendido por años. Además, el proyecto usa características modernas como el `switch` con expresión (`switch (estado) { case "X" -> ... }`).

**¿Qué significa en el código?**
```xml
<!-- En pom.xml -->
<maven.compiler.release>21</maven.compiler.release>
```
Esto le dice al compilador que use Java 21.

---

### 3.2 Maven

**¿Qué es?** Maven es una herramienta de construcción (build tool) para proyectos Java. Su función principal es:
- Descargar automáticamente las bibliotecas (dependencias) que el proyecto necesita.
- Compilar el código fuente.
- Empaquetar el proyecto en un archivo ejecutable (`.jar`).

**¿Dónde se configura?** En el archivo `pom.xml` (Project Object Model) en la raíz del proyecto.

**¿Por qué es importante?** Sin Maven, habría que descargar manualmente archivos `.jar` de Hibernate, PostgreSQL, Lombok, etc. Maven lo hace automáticamente.

**Comando básico para compilar:**
```bash
mvn clean install
```

---

### 3.3 Lombok

**¿Qué es?** Lombok es una biblioteca que genera código Java repetitivo automáticamente mediante anotaciones. Reduce significativamente la cantidad de código a escribir.

**¿Para qué sirve en este proyecto?** Elimina la necesidad de escribir manualmente los métodos `getX()`, `setX()` (getters y setters) en las entidades, así como constructores sin argumentos.

**Anotaciones usadas:**

| Anotación | Qué genera automáticamente |
|---|---|
| `@Getter` | Genera todos los métodos `get` de los atributos |
| `@Setter` | Genera todos los métodos `set` de los atributos |
| `@NoArgsConstructor` | Genera un constructor vacío `public Clase() {}` |

**Ejemplo en código:**
```java
@Getter @Setter @NoArgsConstructor
@Entity @Table(name = "clientes")
public class Cliente implements Serializable {
    private String nombre;
    private String telefono;
    // Lombok genera automáticamente:
    // public String getNombre() { return nombre; }
    // public void setNombre(String nombre) { this.nombre = nombre; }
    // public String getTelefono() { return telefono; }
    // public void setTelefono(String telefono) { this.telefono = telefono; }
    // public Cliente() {}
}
```

**Configuración en pom.xml:**
```xml
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <version>1.18.42</version>
    <scope>provided</scope>  <!-- Solo en compilación, no en el .jar final -->
</dependency>
```

> **IMPORTANTE:** En NetBeans, para que Lombok funcione correctamente, debe estar habilitado el procesamiento de anotaciones. Esto se configura en la sección `<annotationProcessorPaths>` del `pom.xml`.

---

### 3.4 JPA / Jakarta Persistence

**¿Qué es?** JPA (Jakarta Persistence API) es una **especificación** (un conjunto de reglas y contratos) que define cómo los objetos Java se mapean a tablas de base de datos. JPA por sí sola es solo una definición; necesita una implementación que la lleve a cabo.

**Analogía:** JPA es como las "reglas del fútbol" y Hibernate es el equipo que las aplica en el campo.

**¿Para qué sirve?** Permite trabajar con objetos Java en lugar de escribir SQL manualmente. En vez de:
```sql
INSERT INTO clientes (id, nombre, telefono) VALUES ('abc', 'Juan', '12345');
```
Se hace:
```java
Cliente cliente = new Cliente();
cliente.setNombre("Juan");
em.persist(cliente);  // JPA traduce esto a SQL automáticamente
```

**Conceptos clave de JPA:**

| Concepto | Significado |
|---|---|
| `EntityManager` (em) | Objeto que gestiona las entidades: guarda, busca, actualiza, elimina |
| `EntityManagerFactory` | Fábrica que crea instancias de EntityManager (costosa de crear, se hace una sola vez) |
| `Persistence Unit` | Unidad de configuración que agrupa entidades y propiedades de conexión |
| `@Entity` | Anota una clase Java para que JPA la trate como una tabla de base de datos |
| `@Table` | Especifica el nombre de la tabla en la base de datos |
| `@Id` | Marca el atributo que es la clave primaria |
| `@Column` | Configura las propiedades de una columna (nombre, longitud, si puede ser nulo) |
| `@GeneratedValue` | Indica que el valor del `@Id` se genera automáticamente (auto-incremento) |
| `@OneToMany` | Relación "uno a muchos" (ej: un pedido tiene muchos productos) |
| `@ManyToOne` | Relación "muchos a uno" (ej: muchos productos pertenecen a un pedido) |
| `@ManyToMany` | Relación "muchos a muchos" (ej: un producto puede tener varias etiquetas) |
| `@JoinColumn` | Define la columna que actúa como llave foránea (foreign key) |
| `@JoinTable` | Define la tabla intermedia de una relación muchos a muchos |
| `@ElementCollection` | Colección de valores simples (mapa o lista) almacenados en una tabla secundaria |

---

### 3.5 Hibernate ORM

**¿Qué es?** Hibernate es la **implementación de JPA** que se usa en este proyecto. Es el motor real que traduce las anotaciones JPA a instrucciones SQL y ejecuta las consultas contra PostgreSQL.

**ORM** = Object-Relational Mapping (Mapeo Objeto-Relacional). El ORM es el proceso de "traducir" entre el mundo orientado a objetos (clases Java) y el mundo relacional (tablas SQL).

**¿Cómo sabe Hibernate qué hacer?**
1. Lee las anotaciones `@Entity`, `@Table`, `@Column`, etc. en las clases Java.
2. Cuando se llama `em.persist(cliente)`, Hibernate genera automáticamente el SQL:
   ```sql
   INSERT INTO clientes (id, nombre, telefono, ...) VALUES (?, ?, ?, ...)
   ```
3. Cuando se llama `em.find(Cliente.class, id)`, Hibernate genera:
   ```sql
   SELECT * FROM clientes WHERE id = ?
   ```

**Propiedades de Hibernate en persistence.xml:**
```xml
<property name="hibernate.hbm2ddl.auto" value="update"/>
<property name="hibernate.show_sql" value="true"/>
<property name="hibernate.format_sql" value="true"/>
```

- `show_sql`: imprime en consola cada SQL generado (útil para depuración).
- `format_sql`: formatea el SQL impreso para que sea legible.

**Versión usada:** Hibernate 7.0.0.Final (compatible con Jakarta EE 11).

---

### 3.6 PostgreSQL

**¿Qué es?** PostgreSQL es el motor de base de datos relacional donde se almacenan todos los datos del sistema (clientes, pedidos, productos, etc.).

**¿Cómo se conecta?** A través del driver JDBC de PostgreSQL:
```xml
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <version>42.7.7</version>
</dependency>
```

**Cadena de conexión usada:**
```
jdbc:postgresql://localhost:5433/postgres
```
- `localhost` = la base de datos corre en la misma máquina (o en Docker con port mapping).
- `5433` = puerto (diferente al 5432 estándar, probablemente para evitar conflictos).
- `postgres` = nombre de la base de datos.
- Usuario: `admin`, contraseña: `contra`.

---

### 3.7 OpenPDF (LibrePDF)

**¿Qué es?** Biblioteca Java de código abierto para generar documentos PDF desde código.

**¿Para qué sirve en el proyecto?** Para generar:
- Reportes completos de pedidos (todos, pendientes, cobrados).
- Tickets individuales por pedido.

**Uso básico:**
```java
Document doc = new Document(PageSize.A4, 36, 36, 36, 50);
PdfWriter.getInstance(doc, new FileOutputStream(archivo));
doc.open();
doc.add(new Paragraph("Texto aquí"));
doc.close();
```

---

### 3.8 Java Swing

**¿Qué es?** Swing es la biblioteca de Java para crear interfaces gráficas de usuario (GUI) en aplicaciones de escritorio. Proporciona componentes como ventanas, botones, campos de texto, paneles, etc.

**Componentes Swing usados en el proyecto:**

| Componente | Descripción |
|---|---|
| `JFrame` | Ventana principal de la aplicación |
| `JPanel` | Panel contenedor para organizar otros componentes |
| `JLabel` | Texto o imagen no editable |
| `JTextField` | Campo de texto editable de una línea |
| `JPasswordField` | Campo de contraseña (muestra asteriscos) |
| `JButton` | Botón clickeable |
| `JToggleButton` | Botón que puede estar "seleccionado" o no |
| `JTabbedPane` | Panel con pestañas |
| `JScrollPane` | Contenedor con barra de desplazamiento |
| `JOptionPane` | Diálogos modales (alertas, confirmaciones) |
| `ButtonGroup` | Agrupa botones para que solo uno esté activo a la vez |
| `BoxLayout` | Organiza componentes en una columna o fila |
| `BorderLayout` | Divide el espacio en 5 zonas: N, S, E, O, Centro |
| `FlowLayout` | Organiza componentes en fila, con salto automático |
| `GroupLayout` | Layout avanzado usado por el editor visual de NetBeans |

---

## 4. Archivo de configuración pom.xml

El `pom.xml` es el archivo central de Maven. Define:

```xml
<project>
    <!-- Identificación del proyecto -->
    <groupId>com.crsm_procesos</groupId>       <!-- "empresa" o namespace -->
    <artifactId>mavenproject1</artifactId>       <!-- nombre del proyecto -->
    <version>1.0-PinkyPuff</version>            <!-- versión del .jar -->

    <!-- Configuraciones generales -->
    <properties>
        <maven.compiler.release>21</maven.compiler.release>  <!-- Java 21 -->
        <exec.mainClass>view.FrmLogin</exec.mainClass>       <!-- clase que inicia la app -->
    </properties>

    <!-- Dependencias (bibliotecas que descarga Maven automáticamente) -->
    <dependencies>
        <!-- ORM: Hibernate para gestionar la base de datos -->
        <dependency>
            <groupId>org.hibernate.orm</groupId>
            <artifactId>hibernate-core</artifactId>
            <version>7.0.0.Final</version>
        </dependency>

        <!-- Driver de PostgreSQL -->
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <version>42.7.7</version>
        </dependency>

        <!-- Lombok: genera getters, setters y constructores -->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <version>1.18.42</version>
            <scope>provided</scope>
        </dependency>

        <!-- Generación de PDF -->
        <dependency>
            <groupId>com.github.librepdf</groupId>
            <artifactId>openpdf</artifactId>
            <version>1.3.43</version>
        </dependency>
    </dependencies>
</project>
```

---

## 5. Archivo persistence.xml — La conexión a la base de datos

**Ubicación:** `src/main/resources/META-INF/persistence.xml`

**¿Qué es?** Es el archivo de configuración central de JPA. Le dice a Hibernate cómo conectarse a la base de datos y cuáles clases Java son entidades (tablas).

```xml
<?xml version="1.0" encoding="UTF-8"?>
<persistence version="3.2" xmlns="https://jakarta.ee/xml/ns/persistence">

  <!-- Unidad de persistencia: agrupa todo bajo un nombre -->
  <persistence-unit name="pinkyPuffPersistance" transaction-type="RESOURCE_LOCAL">

    <!-- Implementación JPA que se usará -->
    <provider>org.hibernate.jpa.HibernatePersistenceProvider</provider>

    <!-- Lista de clases Java que son entidades (tablas) -->
    <class>model.Cliente</class>
    <class>model.Pedido</class>
    <class>model.Producto</class>
    <class>model.EtiquetaConfig</class>
    <class>model.Administrador</class>

    <properties>
      <!-- URL de conexión a PostgreSQL -->
      <property name="jakarta.persistence.jdbc.url"
                value="jdbc:postgresql://localhost:5433/postgres"/>
      <!-- Usuario de la base de datos -->
      <property name="jakarta.persistence.jdbc.user" value="admin"/>
      <!-- Driver JDBC de PostgreSQL -->
      <property name="jakarta.persistence.jdbc.driver"
                value="org.postgresql.Driver"/>
      <!-- Contraseña -->
      <property name="jakarta.persistence.jdbc.password" value="contra"/>

      <!-- Comportamiento de Hibernate con el esquema de la BD -->
      <property name="hibernate.hbm2ddl.auto" value="update"/>

      <!-- Mostrar SQL en la consola (útil para depurar) -->
      <property name="hibernate.show_sql" value="true"/>
      <property name="hibernate.format_sql" value="true"/>
    </properties>

  </persistence-unit>
</persistence>
```

**Referencia al nombre en JPAUtil.java:**
```java
private static final String UNIDAD_PERSISTENCIA = "pinkyPuffPersistance";
// Este nombre DEBE coincidir exactamente con name="pinkyPuffPersistance" del XML
fabricaGestores = Persistence.createEntityManagerFactory(UNIDAD_PERSISTENCIA);
```

---

### 5.1 Cómo agregar una nueva entidad al persistence.xml

Si se crea una nueva clase Java con `@Entity` (por ejemplo `model.Categoria`), hay que registrarla en el `persistence.xml` para que Hibernate la reconozca:

**Paso 1:** Crear la clase con las anotaciones JPA:
```java
package model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor
@Entity
@Table(name = "categorias")
public class Categoria implements java.io.Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(length = 36, nullable = false)
    private String id;

    @Column(nullable = false)
    private String nombre;
}
```

**Paso 2:** Agregar la línea en `persistence.xml` dentro de `<persistence-unit>`:
```xml
<class>model.Cliente</class>
<class>model.Pedido</class>
<class>model.Producto</class>
<class>model.EtiquetaConfig</class>
<class>model.Administrador</class>
<class>model.Categoria</class>  <!-- ← NUEVA LÍNEA -->
```

**Paso 3:** Gracias a `hibernate.hbm2ddl.auto = update`, al iniciar la aplicación Hibernate creará automáticamente la tabla `categorias` en la base de datos si no existe.

> **En NetBeans:** El archivo `persistence.xml` está en `src/main/resources/META-INF/persistence.xml`. También puede abrirse desde la pestaña "Files" → navegando hasta esa ruta.

---

### 5.2 Qué es `hibernate.hbm2ddl.auto = update`

Esta propiedad controla qué hace Hibernate con el **esquema de la base de datos** al iniciar la aplicación. Los valores posibles son:

| Valor | Comportamiento |
|---|---|
| `create` | **Elimina y crea** todas las tablas al iniciar. ⚠️ Borra todos los datos. |
| `create-drop` | Crea las tablas al iniciar y las **elimina al cerrar**. Solo para tests. |
| `update` | **Compara** el esquema actual con las entidades y aplica solo los cambios necesarios (agrega columnas nuevas, crea tablas que faltan). **No elimina datos.** |
| `validate` | Solo verifica que el esquema coincide con las entidades. Si no coincide, lanza error. |
| `none` | No hace nada con el esquema. |

**En este proyecto se usa `update`**, lo que significa:
- Si una tabla no existe → la crea automáticamente.
- Si una columna no existe → la agrega.
- Si se elimina un atributo de la entidad → la columna queda en la BD (no se borra).
- Los datos existentes no se pierden.

> **IMPORTANTE para producción:** En entornos de producción, `update` puede ser peligroso. Se recomienda usar `validate` o `none` y gestionar los cambios de esquema manualmente con scripts SQL.

---

## 6. Capa de Modelo — Las entidades JPA

Las entidades son clases Java que representan tablas de la base de datos. Cada instancia de la clase es una fila en la tabla.

### 6.1 Administrador

**Archivo:** `src/main/java/model/Administrador.java`
**Tabla:** `administrador`

```java
@Getter @Setter
@Entity
@Table(name = "administrador")
public class Administrador implements Serializable {

    @Id
    @Column(name = "email", nullable = false)
    private String email;           // Clave primaria (el email es único)

    @Column(name = "username", nullable = false)
    private String nombre;          // Nombre visible del admin

    @Column(name = "password_hash", nullable = false)
    private String contrasena;      // Contraseña guardada como hash SHA-256

    @OneToMany(mappedBy = "administrador", fetch = FetchType.LAZY)
    private List<Producto> productos = new ArrayList<>();
    // Un administrador puede registrar muchos productos
}
```

**Puntos importantes:**
- La clave primaria es el **email** (no un número auto-incremental). Esto significa que dos admins no pueden tener el mismo email.
- La contraseña **nunca** se guarda en texto plano; siempre se guarda el resultado de SHA-256.
- `@OneToMany(mappedBy = "administrador")` indica que la relación está definida en la clase `Producto` (en el campo `administrador`). La tabla `administrador` no tiene columna extra para esto.
- `FetchType.LAZY` = la lista de productos no se carga de la BD hasta que se accede a ella.

---

### 6.2 Cliente

**Archivo:** `src/main/java/model/Cliente.java`
**Tabla:** `clientes`

```java
@Getter @Setter @NoArgsConstructor
@Entity @Table(name = "clientes")
public class Cliente implements Serializable {

    @Id @Column(length = 36, nullable = false)
    private String id;               // UUID generado en código (no auto-incremental)

    @Column(nullable = false)
    private String nombre;

    private String telefono;         // Puede ser null

    @Column(length = 500)
    private String descripcion;      // Máx. 500 caracteres

    @Column(name = "fecha_registro")
    private LocalDateTime fechaRegistro;

    @Column(columnDefinition = "VARCHAR(255) NOT NULL DEFAULT 'ACTIVO'")
    private String estado = "ACTIVO"; // Valores posibles: ACTIVO, INACTIVO, BLOQUEADO
}
```

**Puntos importantes:**
- El `id` es un **UUID** (identificador universal único) generado con `UUID.randomUUID().toString()` en el código Java, no por la base de datos.
- `@Column(columnDefinition = "...")` permite definir el SQL exacto para la columna, incluyendo el valor por defecto.
- El estado tiene tres valores posibles: `ACTIVO`, `INACTIVO`, `BLOQUEADO`.

---

### 6.3 Pedido

**Archivo:** `src/main/java/model/Pedido.java`
**Tabla:** `pedidos`

```java
@Getter @Setter @NoArgsConstructor
@Entity @Table(name = "pedidos")
public class Pedido implements Serializable {

    @Id @Column(length = 36, nullable = false)
    private String id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;
    // Muchos pedidos → un cliente. La columna "cliente_id" en la tabla "pedidos"
    // apunta al email del cliente. FetchType.EAGER = se carga siempre junto al pedido.

    @Column(nullable = false)
    private String estado;           // PENDIENTE, COBRADO, CANCELADO

    @Column(name = "fecha_registro")
    private LocalDateTime fechaRegistro;

    @Column(name = "fecha_cobro")
    private LocalDateTime fechaCobro; // Solo tiene valor cuando estado = COBRADO

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL,
               fetch = FetchType.EAGER, orphanRemoval = true)
    private List<Producto> productos = new ArrayList<>();
    // Un pedido contiene muchos productos.
    // cascade = ALL: si se guarda/elimina el pedido, también los productos.
    // orphanRemoval = true: si un producto se quita de la lista, se elimina de la BD.

    public BigDecimal getTotal() {
        // Suma precio × cantidad de todos los productos del pedido
        return productos.stream()
            .map(p -> p.getPrecio().multiply(BigDecimal.valueOf(p.getCantidad())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
```

**Puntos importantes:**
- `CascadeType.ALL` significa que las operaciones (crear, editar, eliminar) se propagan automáticamente a los productos del pedido.
- `orphanRemoval = true` asegura que si se remueve un producto de la lista `productos`, se elimina también de la base de datos.
- El método `getTotal()` calcula el monto total en tiempo real sumando todos los productos.

---

### 6.4 Producto

**Archivo:** `src/main/java/model/Producto.java`
**Tabla:** `productos`

```java
@Getter @Setter @NoArgsConstructor
@Entity @Table(name = "productos")
public class Producto implements Serializable {

    @Id @Column(length = 36, nullable = false)
    private String id;

    private String tipo;       // Ej: "Ropa", "Bolso"
    private String estilo;     // Ej: "Casual", "Formal"
    private String talla;      // Ej: "M", "L"

    @Column(length = 500)
    private String descripcion;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal precio;   // Número decimal con 10 dígitos totales y 2 decimales

    @Column(nullable = false)
    private int cantidad;

    @Column(name = "fecha_registro")
    private LocalDateTime fechaRegistro;

    // Mapa de atributos personalizados (categorías custom)
    // Se almacena en la tabla "producto_atributos"
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "producto_atributos",
                     joinColumns = @JoinColumn(name = "producto_id"))
    @MapKeyColumn(name = "categoria")
    @Column(name = "valor")
    private Map<String, String> atributos = new HashMap<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "administrador_email")
    private Administrador administrador;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pedido_id", nullable = true)
    private Pedido pedido;

    // Relación muchos a muchos con etiquetas
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "producto_etiquetas",
        joinColumns = @JoinColumn(name = "producto_id"),
        inverseJoinColumns = @JoinColumn(name = "etiqueta_id")
    )
    private List<EtiquetaConfig> etiquetas = new ArrayList<>();
}
```

**Puntos importantes:**
- `@ElementCollection` con `Map<String, String>` permite almacenar atributos extra (categorías personalizadas) sin necesidad de una entidad separada. Se guardan en la tabla `producto_atributos`.
- `@ManyToMany` con `@JoinTable` define la relación de "muchos a muchos" con `EtiquetaConfig`, usando la tabla intermedia `producto_etiquetas`.
- `BigDecimal` se usa para precios porque, a diferencia de `double` o `float`, no tiene problemas de redondeo decimal (crucial en cálculos monetarios).

---

### 6.5 EtiquetaConfig

**Archivo:** `src/main/java/model/EtiquetaConfig.java`
**Tabla:** `etiquetas_config`

```java
@Getter @Setter @NoArgsConstructor
@Entity @Table(name = "etiquetas_config")
public class EtiquetaConfig implements Serializable {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;            // Auto-incremental (BIGSERIAL en PostgreSQL)

    @Column(nullable = false)
    private String categoria;   // Ej: "TIPO", "ESTILO", "TALLA", "PRECIO_RAPIDO", "CATEGORIA_CUSTOM"

    @Column(nullable = false)
    private String valor;       // Ej: "Ropa", "Casual", "XL", "Base"

    @Column(name = "valor_numerico", precision = 10, scale = 2)
    private BigDecimal valorNumerico; // Solo usado para PRECIO_RAPIDO

    private int orden;          // Para controlar el orden de aparición

    @ManyToMany(mappedBy = "etiquetas", fetch = FetchType.LAZY)
    private List<Producto> productos = new ArrayList<>();
}
```

**Puntos importantes:**
- `@GeneratedValue(strategy = GenerationType.IDENTITY)` hace que el `id` sea auto-incremental (como `SERIAL` en PostgreSQL). No hay que asignarlo manualmente.
- Esta entidad es la que almacena los "chips" configurables del formulario: tipos, estilos, tallas, precios rápidos y categorías personalizadas.
- Las categorías reservadas del sistema son: `TIPO`, `ESTILO`, `TALLA`, `PRECIO_RAPIDO`, `CATEGORIA_CUSTOM`.

---

### 6.6 Relaciones entre entidades

```
Administrador ──< Producto        (Un admin registra muchos productos)
Cliente       ──< Pedido          (Un cliente puede tener muchos pedidos)
Pedido        ──< Producto        (Un pedido contiene muchos productos)
Producto      >─< EtiquetaConfig  (Un producto puede tener varias etiquetas
                                   y una etiqueta puede aplicar a varios productos)
Producto      ──< producto_atributos (Atributos extra en tabla separada)
```

**Diagrama de relaciones simplificado:**

```
┌────────────────┐     1..N    ┌────────────────┐
│  Administrador │ ──────────> │    Producto    │
│  (email PK)    │             │  (id UUID PK)  │
└────────────────┘             │                │
                               │ tipo           │
┌────────────────┐     1..N    │ estilo         │ N..N  ┌────────────────┐
│    Cliente     │ ──────────> │ talla          │ ────> │ EtiquetaConfig │
│  (id UUID PK)  │             │ precio         │       │ (id BIGSERIAL) │
└────────────────┘             │ cantidad       │       │ categoria      │
        │                      │ atributos(map) │       │ valor          │
        │ 1..N                 └────────────────┘       └────────────────┘
        v                             ^
┌────────────────┐     1..N           │
│    Pedido      │ ──────────────────┘
│  (id UUID PK)  │
│  estado        │
│  fechaRegistro │
│  fechaCobro    │
└────────────────┘
```

---

## 7. Capa de Persistencia — Repositorios y Controladores JPA

### 7.1 JPAUtil — El singleton de conexión

**Archivo:** `src/main/java/persistencia/JPAUtil.java`

**¿Para qué sirve?** Es una clase utilitaria que gestiona la creación del `EntityManagerFactory` (que es una operación costosa) y la del `EntityManager` (que se usa por operación).

```java
public class JPAUtil {

    private static final String UNIDAD_PERSISTENCIA = "pinkyPuffPersistance";

    // El factory se crea UNA SOLA VEZ en toda la aplicación (Singleton)
    private static EntityManagerFactory fabricaGestores;

    private JPAUtil() {}  // Constructor privado → no se puede instanciar

    // Método sincronizado para evitar problemas en entornos multi-hilo
    public static synchronized EntityManagerFactory obtenerFabricaGestores() {
        if (fabricaGestores == null || !fabricaGestores.isOpen()) {
            fabricaGestores = Persistence.createEntityManagerFactory(UNIDAD_PERSISTENCIA);
        }
        return fabricaGestores;
    }

    // Crea un EntityManager nuevo por cada operación
    public static EntityManager obtenerGestorEntidades() {
        return obtenerFabricaGestores().createEntityManager();
    }

    // Se llama al cerrar la aplicación
    public static void cerrar() {
        if (fabricaGestores != null && fabricaGestores.isOpen()) {
            fabricaGestores.close();
        }
    }
}
```

**¿Por qué el EntityManagerFactory se crea solo una vez?**
Crear el `EntityManagerFactory` implica leer el `persistence.xml`, establecer la conexión al pool de base de datos, y cargar todos los metadatos de las entidades. Es muy costoso. Por eso se guarda en una variable estática y se reutiliza.

En cambio, el `EntityManager` es liviano y se crea por cada operación (consulta, inserción, etc.) y se cierra en el `finally {}` para liberar recursos.

---

### 7.2 Interfaces Repositorio

Cada entidad tiene una **interfaz** que define qué operaciones están disponibles. Ejemplo con `RepositorioCliente`:

```java
public interface RepositorioCliente {
    void crear(Cliente cliente) throws PreexistingEntityException;
    void editar(Cliente cliente) throws NonexistentEntityException;
    void eliminar(String id) throws NonexistentEntityException;
    List<Cliente> buscarTodos();
    List<Cliente> buscarPorEstado(String estado);
    Cliente buscarPorId(String id);
    Cliente buscarPorNombre(String nombre);
    int contarTotal();
}
```

**¿Por qué usar interfaces?** Permite cambiar la implementación (por ejemplo, cambiar de PostgreSQL a MySQL) sin modificar el código que usa estas interfaces. El `PedidoService` trabaja con `RepositorioCliente`, no con `ClienteJpaController`, lo que facilita el testing y el mantenimiento.

---

### 7.3 Controladores JPA (implementaciones)

Son las clases que **implementan** las interfaces de repositorio y contienen el código real de acceso a datos con JPA.

**Estructura común de cada método:**

```java
// Patrón general de un método CRUD con JPA
public void crear(Cliente cliente) throws PreexistingEntityException {
    EntityManager em = JPAUtil.obtenerGestorEntidades(); // 1. Obtener EntityManager
    try {
        // 2. Verificar si ya existe (para evitar duplicados)
        if (em.find(Cliente.class, cliente.getId()) != null)
            throw new PreexistingEntityException("...");

        em.getTransaction().begin();    // 3. Iniciar transacción
        em.persist(cliente);            // 4. Guardar objeto en BD
        em.getTransaction().commit();   // 5. Confirmar cambios

    } catch (PreexistingEntityException e) {
        throw e;                        // Re-lanzar errores esperados
    } catch (Exception e) {
        if (em.getTransaction().isActive())
            em.getTransaction().rollback(); // 6. Revertir si hay error
        throw new RuntimeException(e);
    } finally {
        em.close();                     // 7. SIEMPRE cerrar el EntityManager
    }
}
```

**Los 4 métodos básicos de JPA (CRUD):**

| Operación | Método JPA | SQL equivalente |
|---|---|---|
| Crear | `em.persist(objeto)` | `INSERT INTO ...` |
| Leer | `em.find(Clase.class, id)` | `SELECT * FROM ... WHERE id = ?` |
| Actualizar | `em.merge(objeto)` | `UPDATE ... SET ...` |
| Eliminar | `em.remove(objeto)` | `DELETE FROM ... WHERE id = ?` |

**JPQL (Java Persistence Query Language):**

JPQL es el lenguaje de consulta de JPA. Es similar a SQL pero opera sobre **clases Java**, no sobre tablas:

```java
// En lugar de: SELECT * FROM clientes WHERE nombre = ?
em.createQuery("SELECT c FROM Cliente c WHERE c.nombre = :n", Cliente.class)
  .setParameter("n", nombre)
  .getResultList();

// "Cliente" es el nombre de la clase Java (no la tabla "clientes")
// "c.nombre" se refiere al atributo Java (no la columna)
```

**JOIN FETCH en consultas:**
```java
// Esta consulta carga los productos del pedido en la misma consulta SQL
// (evita el problema N+1: hacer N consultas adicionales para cargar asociaciones)
"SELECT DISTINCT p FROM Pedido p LEFT JOIN FETCH p.productos ORDER BY p.fechaRegistro DESC"
```

---

## 8. Capa de Servicio — La lógica de negocio

**Archivo:** `src/main/java/service/PedidoService.java`

**¿Para qué sirve?** Centraliza las **reglas de negocio** del sistema. Por ejemplo:
- Al agregar un producto, si el cliente no existe → crearlo automáticamente.
- Al agregar un producto, si el cliente no tiene un pedido pendiente → crear uno.
- Al marcar un pedido como cobrado → registrar la `fechaCobro`.

Esto evita que estos pasos estén dispersos en los controladores de UI y garantiza que la lógica sea consistente.

```java
public class PedidoService implements SujetoDatos {

    // Depende de interfaces, no de implementaciones concretas
    private final RepositorioCliente  repoCliente;
    private final RepositorioPedido   repoPedido;
    private final RepositorioProducto repoProducto;

    // Lista de observadores para el patrón Observer
    private final List<ObservadorDatos> observadores = new ArrayList<>();

    public Pedido agregarProducto(...) throws Exception {
        // Regla 1: si el cliente no existe, crearlo
        Cliente cliente = repoCliente.buscarPorNombre(nombreCliente);
        if (cliente == null) {
            cliente = new Cliente(UUID.randomUUID().toString(), ...);
            repoCliente.crear(cliente);
        }

        // Regla 2: si no tiene pedido pendiente, crear uno
        Pedido pedido = repoPedido.buscarPendientePorCliente(cliente);
        if (pedido == null) {
            pedido = new Pedido(UUID.randomUUID().toString(), cliente, "PENDIENTE", ...);
            repoPedido.crear(pedido);
        }

        // Regla 3: crear y asociar el producto
        Producto producto = new Producto(...);
        producto.setPedido(pedido);
        repoProducto.crear(producto);

        // Regla 4: notificar a la UI para que se actualice
        notificarObservadores();

        return repoPedido.buscarPorId(pedido.getId());
    }
}
```

---

## 9. Patrones de diseño implementados

Los patrones de diseño son soluciones probadas a problemas comunes de programación.

### 9.1 MVC (Modelo–Vista–Controlador)

**¿Qué es?** Separa el código en tres capas con responsabilidades distintas:

| Capa | Responsabilidad | Clases en el proyecto |
|---|---|---|
| **Modelo** | Datos y lógica de negocio | `model/`, `service/`, `persistencia/` |
| **Vista** | Interfaz gráfica que el usuario ve | `view/FrmLogin`, `view/FrmDashboard` |
| **Controlador** | Intermediario: recibe eventos de la Vista y llama al Modelo | `controller/ControladorFrmLogin`, `controller/ControladorDashboard` |

**Flujo:**
```
Usuario hace clic en "Iniciar Sesión"
        ↓
FrmLogin (Vista) → llama a controlador.manejarLogin()
        ↓
ControladorFrmLogin (Controlador) → llama a autenticacion.obtenerAdministradorAutenticado()
        ↓
SistemaAutenticacion (Modelo) → consulta la BD → devuelve Administrador o null
        ↓
ControladorFrmLogin → según resultado: abre FrmDashboard o muestra error
        ↓
FrmDashboard (Vista) → se muestra al usuario
```

**Ventaja:** Si se quiere cambiar la interfaz (por ejemplo, de Swing a JavaFX), solo se modifica la capa Vista sin tocar la lógica de negocio.

---

### 9.2 Patrón Observer (Observador)

**¿Qué es?** Permite que varios objetos sean notificados automáticamente cuando el estado de otro objeto cambia.

**¿Cómo funciona en el proyecto?**

El `PedidoService` es el **Sujeto** (el que emite notificaciones).
El `ControladorDashboard` es el **Observador** (el que reacciona).

```java
// Interfaz Observador
public interface ObservadorDatos {
    void actualizar();  // Método que se llama cuando hay cambios
}

// Interfaz Sujeto
public interface SujetoDatos {
    void agregarObservador(ObservadorDatos observador);
    void eliminarObservador(ObservadorDatos observador);
    void notificarObservadores();
}

// PedidoService implementa SujetoDatos
public class PedidoService implements SujetoDatos {
    private final List<ObservadorDatos> observadores = new ArrayList<>();

    public void notificarObservadores() {
        for (ObservadorDatos obs : observadores) obs.actualizar();
        // Llama a actualizar() en cada observador registrado
    }

    public void marcarCobrado(String pedidoId) throws ... {
        // ... cambia el estado del pedido ...
        notificarObservadores(); // ← Notifica a la UI para que se refresque
    }
}

// ControladorDashboard implementa ObservadorDatos
public class ControladorDashboard implements ObservadorDatos {

    public ControladorDashboard(...) {
        servicioPedido.agregarObservador(this); // Se registra como observador
    }

    @Override
    public void actualizar() {
        refrescarTodo(); // Cuando hay cambios, refresca toda la interfaz
    }
}
```

**Resultado:** Cada vez que se agrega un producto, se cobra un pedido o se cancela uno, la interfaz gráfica se actualiza automáticamente sin que la lógica de negocio sepa nada sobre la UI.

---

### 9.3 Patrón Repository (Repositorio)

**¿Qué es?** Abstrae el acceso a datos detrás de una interfaz. El código de negocio no sabe si los datos vienen de PostgreSQL, un archivo, o la memoria.

**En el proyecto:**
- `RepositorioCliente` (interfaz) → define el contrato de acceso.
- `ClienteJpaController` (implementación) → implementa el contrato con JPA + PostgreSQL.
- `PedidoService` trabaja con `RepositorioCliente`, no con `ClienteJpaController`.

---

### 9.4 Singleton

**¿Qué es?** Garantiza que una clase tenga **una sola instancia** en toda la aplicación.

**En el proyecto:** `JPAUtil` implementa este patrón para el `EntityManagerFactory`:
```java
private static EntityManagerFactory fabricaGestores; // Una sola instancia

public static synchronized EntityManagerFactory obtenerFabricaGestores() {
    if (fabricaGestores == null || !fabricaGestores.isOpen()) {
        fabricaGestores = Persistence.createEntityManagerFactory(UNIDAD_PERSISTENCIA);
        // Solo se crea la primera vez
    }
    return fabricaGestores;
}
```

---

## 10. Capa de Vista — Interfaz gráfica con Swing

### 10.1 FrmLogin — Formulario de acceso

**Archivo:** `src/main/java/view/FrmLogin.java`

Es la primera ventana que ve el usuario. Tiene:
- Campo de usuario (`txtUsername`)
- Campo de contraseña (`txtPassword`)
- Botón "Iniciar Sesión" (`btnLogin`)
- Botón de cierre personalizado (`LblExit`)

La ventana **no tiene barra de título** (`setUndecorated(true)`) y **no es redimensionable** (`setResizable(false)`). El arrastre de la ventana se implementa manualmente capturando eventos de ratón en `jPanel7`.

**Punto de entrada de la aplicación:**
```java
public static void main(String args[]) {
    // invokeLater asegura que la interfaz se crea en el hilo de Swing (EDT)
    java.awt.EventQueue.invokeLater(() -> new FrmLogin().setVisible(true));
}
```

**¿Por qué `EventQueue.invokeLater`?** Swing no es hilo-seguro (thread-safe). Todas las modificaciones a la interfaz gráfica deben hacerse en el Event Dispatch Thread (EDT). `invokeLater` garantiza esto.

---

### 10.2 FrmDashboard — Panel principal

**Archivo:** `src/main/java/view/FrmDashboard.java`

Es la ventana principal post-login. Se abre maximizada (`JFrame.MAXIMIZED_BOTH`) y contiene:
- **Panel de contadores** en la parte superior: pendientes, por cobrar, cobrados hoy.
- **JTabbedPane** con 6 pestañas:
  - `+ Pedidos` → Formulario para agregar nuevos productos/pedidos.
  - `Todos` → Lista de todos los pedidos con filtros.
  - `Clientes` → Lista de clientes con filtros.
  - `Reporte` → Estadísticas y exportación PDF.
  - `Configuraciones` → Gestión de etiquetas (tipos, estilos, etc.).
  - `Configurar credenciales` → Cambiar nombre, email y contraseña del admin.

**Construcción del ControladorDashboard en el constructor:**
```java
public FrmDashboard(Administrador administrador) {
    initComponents();  // Crea los componentes visuales básicos (generado por NetBeans)

    // Instanciar repositorios
    ClienteJpaController repoCliente = new ClienteJpaController();
    // ... más repositorios ...

    // Crear el servicio de negocio
    PedidoService servicioPedido = new PedidoService(repoCliente, repoPedido, repoProducto);

    // Crear el controlador y pasarle referencias a los paneles de la vista
    controlador = new ControladorDashboard(
        administrador, servicioPedido, repoEtiqueta, repoAdmin,
        tabPedidos, tabTodosPedidos, tabClientes, tabReporte,
        tabConfiguraciones, tabConfigurarPassword,
        lblContadorPendientes, lblContadorPorCobrar, lblContadorCobradosHoy
    );

    controlador.inicializar(); // El controlador construye el contenido de cada pestaña
}
```

---

### 10.3 Archivos .form de NetBeans

**Archivos:** `FrmLogin.form`, `FrmDashboard.form`

Los archivos `.form` son archivos XML que NetBeans usa para guardar el **diseño visual** de los formularios creados con el editor de arrastrar y soltar (drag & drop).

**Relación entre .form y .java:**
- El `.form` describe la estructura visual en XML.
- El `.java` contiene el método `initComponents()` que **nunca debe modificarse manualmente** (está marcado con `//GEN-BEGIN` y `//GEN-END`).

**Para modificar el diseño:**
1. Abrir el archivo `.form` en NetBeans (se ve el diseñador visual).
2. Arrastrar componentes, cambiar propiedades.
3. NetBeans regenera automáticamente el bloque `initComponents()` en el `.java`.

**¿Qué pasa si modificas manualmente el código entre `//GEN-BEGIN` y `//GEN-END`?** NetBeans lo sobreescribirá la próxima vez que guardes el `.form`.

> **IMPORTANTE:** Las pestañas del `JTabbedPane` en el `.form` son paneles vacíos. El contenido real (chips, formularios, listas) lo construye programáticamente el `ControladorDashboard` en `inicializar()`.

---

## 11. Capa de Controlador — Los controladores de UI

### 11.1 ControladorFrmLogin

**Archivo:** `src/main/java/controller/ControladorFrmLogin.java`

Gestiona los eventos del formulario de login:

```java
public void manejarLogin() {
    vista.deshabilitarBotonLogin(); // Evita doble clic

    String usuario = vista.getUsuarioIngresado();
    String contrasena = vista.getContrasenaIngresada();

    // Validación básica
    if (!validarCamposVacios(usuario, contrasena)) {
        vista.habilitarBotonLogin();
        return;
    }

    // SwingWorker: ejecuta la autenticación en un hilo separado
    // para no bloquear la interfaz gráfica
    new SwingWorker<Administrador, Void>() {
        @Override
        protected Administrador doInBackground() {
            // Este código corre en un hilo de fondo (no en el EDT)
            return autenticacion.obtenerAdministradorAutenticado(usuario, contrasena);
        }

        @Override
        protected void done() {
            // Este código corre en el EDT (puede tocar la interfaz)
            Administrador admin = get();
            if (admin != null) {
                vista.dispose();
                new FrmDashboard(admin).setVisible(true);
            } else {
                intentosFallidos++;
                if (intentosFallidos >= MAX_INTENTOS) System.exit(0);
                // Mostrar error y re-habilitar botón
            }
        }
    }.execute();
}
```

**¿Por qué `SwingWorker`?** La autenticación implica consultas a la base de datos que pueden tardar. Si se ejecutaran en el EDT (hilo principal de Swing), la interfaz se congelaría. `SwingWorker` separa el trabajo pesado del hilo de UI.

---

### 11.2 ControladorDashboard

**Archivo:** `src/main/java/controller/ControladorDashboard.java`

Es el controlador principal. Construye y gestiona el contenido de todas las pestañas del dashboard. Implementa `ObservadorDatos` para recibir notificaciones del `PedidoService`.

**Métodos principales:**

| Método | Función |
|---|---|
| `inicializar()` | Construye el contenido inicial de todas las pestañas |
| `actualizar()` | Implementación del patrón Observer; refresca todo |
| `setupTabTodos()` | Construye la pestaña "Todos" con filtros y lista de pedidos |
| `setupTabClientes()` | Construye la pestaña "Clientes" con filtros y lista |
| `setupTabReporte()` | Construye la pestaña "Reporte" con estadísticas y botones PDF |
| `setupTabConfiguraciones()` | Construye la pestaña de etiquetas configurables |
| `crearTarjetaPedido(Pedido)` | Crea el componente visual de una tarjeta de pedido |
| `actualizarContadores()` | Actualiza los números en la barra superior |

---

### 11.3 ControladorTabPedidos

**Archivo:** `src/main/java/controller/ControladorTabPedidos.java`

Gestiona específicamente la pestaña `+ Pedidos`, que es el formulario para agregar nuevos productos. Contiene:
- Los paneles de chips de tipo, estilo, talla y categorías personalizadas.
- El formulario (cliente, precio, descripción, cantidad).
- Los botones de precio rápido.

**Método `onAgregarProducto()`:** Valida el formulario y llama a `servicioPedido.agregarProducto(...)`.

---

### 11.4 PlaceholderController

**Archivo:** `src/main/java/controller/PlaceholderController.java`

Gestiona el **texto de marcador de posición** (placeholder) en los campos de texto. Como Swing no tiene soporte nativo para placeholder text, esta clase simula el comportamiento:
- Muestra texto gris de guía cuando el campo está vacío.
- Al hacer clic, borra el texto de guía y cambia el color a negro.
- Si el usuario borra todo, vuelve a mostrar el texto de guía en gris.

---

### 11.5 SistemaAutenticacion

**Archivo:** `src/main/java/controller/SistemaAutenticacion.java`

Encapsula la lógica de autenticación:

```java
public Administrador obtenerAdministradorAutenticado(String nombre, String contrasena) {
    Administrador admin = repositorio.buscarPorNombre(nombre);
    if (admin == null) return null;

    // Compara el hash SHA-256 de la contraseña ingresada
    // con el hash almacenado en la base de datos
    return admin.getContrasena().equals(HashContrasena.calcular(contrasena))
           ? admin : null;
}
```

---

### 11.6 ReportePDF

**Archivo:** `src/main/java/controller/ReportePDF.java`

Genera documentos PDF usando la biblioteca OpenPDF. Tiene dos métodos públicos:
- `generarReportePedidos(List<Pedido>, titulo, padre)` → Reporte de lista de pedidos.
- `generarTicketPedido(Pedido, padre)` → Ticket individual de un pedido.

El proceso es:
1. Abre un `JFileChooser` para que el usuario elija dónde guardar el archivo.
2. Crea un `Document` PDF con OpenPDF.
3. Agrega tablas, párrafos y estilos al documento.
4. Cierra el documento y ofrece abrirlo automáticamente.

---

## 12. Utilidades del sistema

### 12.1 EstiloUI — Estilos y componentes visuales

**Archivo:** `src/main/java/utils/EstiloUI.java`

**¿Para qué sirve?** Centraliza todos los estilos visuales y la creación de componentes reutilizables. Evita duplicar código de estilos en múltiples controladores.

**Clase no instanciable** (constructor privado, todos los métodos son estáticos).

**Paletas de colores:**
```java
// Formato: {color fondo, color texto, color borde/acento}
// Paleta rosa usada en todos los chips del proyecto
public static final Color[][] PALETA_TIPO = {
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    // ...
};

// Colores de estado para clientes
public static final Color[] COLORES_ESTADO_ACTIVO    = {color("EAF3DE"), color("27500A"), color("639922")};
public static final Color[] COLORES_ESTADO_INACTIVO  = {color("F1EFE8"), color("444444"), color("888780")};
public static final Color[] COLORES_ESTADO_BLOQUEADO = {color("FCEBEB"), color("791F1F"), color("F09595")};
```

**Componentes creados por EstiloUI:**

| Método | Qué crea |
|---|---|
| `crearBadge(texto, fondo, frente)` | Etiqueta pill (redondeada) para mostrar estado/categoría |
| `crearChip(texto, colores[])` | Botón toggle redondeado con borde más grueso al seleccionar |
| `crearBotonAccion(texto, fondo, frente, borde)` | Botón con colores y borde personalizados |
| `crearStatBox(valor, etiqueta)` | Caja de estadística con valor grande y etiqueta pequeña |
| `crearBarraGrafico(etiq, val, max, color)` | Fila con barra de progreso para gráficos |
| `crearSeccionLabel(texto)` | Label de encabezado en gris oscuro con mayúsculas |
| `crearLabel(texto)` | Label de formulario gris |
| `crearMensajeVacio(texto)` | Panel con mensaje en cursiva cuando no hay datos |
| `crearFilaConfig(texto, runnable)` | Fila con texto y botón "Eliminar" |
| `crearTarjetaCliente(cliente, editar, estado)` | Tarjeta completa de cliente |
| `crearDivisor(top, bottom)` | Línea separadora horizontal |

**Método `color(String hex)`:**
```java
public static Color color(String hex) {
    return Color.decode("#" + hex); // Convierte "FCE8F2" a un objeto Color
}
```

**Chips con pintura personalizada (`paintComponent`):**
Los `JToggleButton` y `JButton` de precio rápido sobrescriben `paintComponent(Graphics g)` para dibujar esquinas redondeadas usando `Graphics2D.fillRoundRect()` y `drawRoundRect()`. Esto no es posible con los estilos estándar de Swing.

---

### 12.2 HashContrasena — Seguridad de contraseñas

**Archivo:** `src/main/java/utils/HashContrasena.java`

```java
public static String calcular(String contrasena) {
    MessageDigest md = MessageDigest.getInstance("SHA-256");
    byte[] hash = md.digest(contrasena.getBytes(StandardCharsets.UTF_8));
    StringBuilder sb = new StringBuilder();
    for (byte b : hash) sb.append(String.format("%02x", b));
    return sb.toString();
    // Ejemplo: "admin123" → "240be518..." (64 caracteres hexadecimales)
}
```

**SHA-256** convierte cualquier texto en una cadena de 64 caracteres hexadecimales. Es un proceso **irreversible**: no se puede saber la contraseña original a partir del hash. Solo se verifica comparando el hash de lo ingresado con el hash almacenado.

---

### 12.3 CrearAdministradorPrueba

**Archivo:** `src/main/java/utils/CrearAdministradorPrueba.java`

Clase utilitaria con un método `main()` que se puede ejecutar **una sola vez** para crear o actualizar el administrador en la base de datos.

**Cómo ejecutarla en NetBeans:**
1. Clic derecho en la clase `CrearAdministradorPrueba`.
2. "Run File" (o Shift+F6).

Esto crea un admin con:
- Email: `admin@correo.es`
- Nombre: `admin`
- Contraseña: `contraxd` (almacenada como hash)

**Para cambiar las credenciales por defecto**, modificar las líneas:
```java
String correo   = "admin@correo.es";  // ← Cambiar aquí
String nombre   = "admin";            // ← Cambiar aquí
String contrasena = "contraxd";       // ← Cambiar aquí
```

---

### 12.4 configuraciones.xml

**Archivo:** `src/main/java/utils/configuraciones.xml`

Archivo XML con parámetros de conexión alternativos. Actualmente apunta a una base de datos diferente (`system`). Este archivo no está siendo usado activamente por el código principal (la configuración activa está en `persistence.xml`).

---

## 13. Esquema de la base de datos

El archivo `schema.sql` en la raíz del proyecto contiene el SQL para crear todas las tablas manualmente. Se puede ejecutar en psql o pgAdmin si se necesita recrear la base desde cero.

**Tablas del sistema:**

| Tabla | Descripción |
|---|---|
| `administrador` | Usuarios con acceso al sistema (email como PK) |
| `clientes` | Clientes registrados (UUID como PK) |
| `pedidos` | Pedidos de los clientes (UUID como PK, FK a clientes) |
| `productos` | Productos dentro de pedidos (UUID como PK, FK a pedidos y administrador) |
| `etiquetas_config` | Etiquetas configurables (tipo, estilo, talla, precio, custom) |
| `producto_atributos` | Atributos personalizados por producto (tabla secundaria sin PK propia) |
| `producto_etiquetas` | Tabla intermedia de la relación N:N entre productos y etiquetas |

---

## 14. Cómo ver las tablas en Windows con Docker

Si la base de datos PostgreSQL corre en un contenedor Docker, estos son los pasos para verificar y consultar las tablas desde Windows.

### Requisitos previos

- Docker Desktop instalado y corriendo.
- El contenedor de PostgreSQL iniciado (con el `docker-compose up` correspondiente).

### Paso 1 — Verificar que el contenedor está corriendo

Abrir PowerShell o CMD:
```powershell
docker ps
```
Buscar el contenedor de PostgreSQL en la lista. El nombre puede ser algo como `postgres`, `db`, o el nombre definido en el `docker-compose.yml`.

### Paso 2 — Conectarse al contenedor

```powershell
docker exec -it NOMBRE_CONTENEDOR bash
```
Reemplazar `NOMBRE_CONTENEDOR` por el nombre real. Por ejemplo:
```powershell
docker exec -it postgres bash
```

### Paso 3 — Conectarse a PostgreSQL dentro del contenedor

```bash
psql -U admin -d postgres
```
- `-U admin` = usuario definido en `persistence.xml`.
- `-d postgres` = nombre de la base de datos.

### Paso 4 — Comandos útiles dentro de psql

```sql
-- Ver todas las tablas del esquema público
\dt

-- Describir la estructura de una tabla (columnas, tipos, constraints)
\d clientes
\d pedidos
\d productos
\d etiquetas_config
\d administrador

-- Ver el contenido de las tablas
SELECT * FROM administrador;
SELECT * FROM clientes;
SELECT * FROM pedidos;
SELECT * FROM productos;
SELECT * FROM etiquetas_config;
SELECT * FROM producto_atributos;
SELECT * FROM producto_etiquetas;

-- Contar filas en una tabla
SELECT COUNT(*) FROM clientes;

-- Ver pedidos con nombre del cliente (JOIN)
SELECT p.id, c.nombre, p.estado, p.fecha_registro
FROM pedidos p
JOIN clientes c ON p.cliente_id = c.id
ORDER BY p.fecha_registro DESC;

-- Ver productos de un pedido específico
SELECT pr.tipo, pr.estilo, pr.talla, pr.precio, pr.cantidad
FROM productos pr
WHERE pr.pedido_id = 'ID_DEL_PEDIDO_AQUI';

-- Ver etiquetas por categoría
SELECT * FROM etiquetas_config WHERE categoria = 'TIPO' ORDER BY orden;
SELECT * FROM etiquetas_config WHERE categoria = 'ESTILO' ORDER BY orden;
SELECT * FROM etiquetas_config WHERE categoria = 'PRECIO_RAPIDO' ORDER BY orden;

-- Salir de psql
\q
```

### Alternativa gráfica: pgAdmin (Windows)

pgAdmin es una interfaz gráfica para administrar PostgreSQL. Pasos para conectar:

1. Descargar e instalar pgAdmin desde su sitio oficial.
2. Abrir pgAdmin → clic derecho en "Servers" → "Register" → "Server".
3. En la pestaña "General": poner cualquier nombre (ej: "PinkyPuff Local").
4. En la pestaña "Connection":
   - **Host:** `localhost`
   - **Port:** `5433`
   - **Maintenance database:** `postgres`
   - **Username:** `admin`
   - **Password:** `contra`
5. Clic en "Save".

Desde pgAdmin se pueden ver las tablas expandiendo: `Servers → PinkyPuff Local → Databases → postgres → Schemas → public → Tables`.

Para ejecutar SQL: clic en cualquier tabla → clic derecho → "Query Tool".

---

## 15. Cómo cambiar estilos visuales de los componentes

Todos los estilos centralizados están en `utils/EstiloUI.java`.

### Cambiar colores de los chips (tipo, estilo, talla)

Los chips usan las paletas `PALETA_TIPO`, `PALETA_ESTILO`, `PALETA_PRECIO` definidas al inicio de `EstiloUI.java`:

```java
// Formato: {color_fondo, color_texto, color_borde_acento}
// Actualmente todos los chips son rosa; para cambiarlos:
public static final Color[][] PALETA_TIPO = {
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},  // índice 0
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},  // índice 1
    // ...
};

// Ejemplo: cambiar el primer tipo a azul
public static final Color[][] PALETA_TIPO = {
    {color("E3F0FB"), color("042C53"), color("378ADD")},  // azul
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},  // rosa
    // ...
};
```

El índice en la paleta se elige según la posición de la etiqueta en la lista (`idx % PALETA_TIPO.length`), por lo que la paleta puede ser de cualquier tamaño.

### Cambiar colores de estado de pedidos (en tarjetas)

En `ControladorDashboard.java`, método `crearTarjetaPedido()`:
```java
// Fondo de la tarjeta según estado
Color colorFondo = "PENDIENTE".equals(estado) ? c("FAEEDA")   // ← Cambiar aquí
    : "COBRADO".equals(estado) ? c("EAF3DE") : c("F1EFE8");

// Borde izquierdo de la tarjeta según estado
Color colorBorde = "PENDIENTE".equals(estado) ? c("EF9F27")   // ← Cambiar aquí
    : "COBRADO".equals(estado) ? c("639922") : c("888780");
```

### Cambiar colores de estado de clientes

En `EstiloUI.java`:
```java
public static final Color[] COLORES_ESTADO_ACTIVO    = {color("EAF3DE"), color("27500A"), color("639922")};
public static final Color[] COLORES_ESTADO_INACTIVO  = {color("F1EFE8"), color("444444"), color("888780")};
public static final Color[] COLORES_ESTADO_BLOQUEADO = {color("FCEBEB"), color("791F1F"), color("F09595")};
// Formato: {fondo, texto, borde}
```

### Cambiar fuentes

Los textos usan `"SansSerif"` como familia de fuente genérica. Para cambiar:
```java
// En EstiloUI.java, cambiar FAMILIA_FUENTE:
public static final String FAMILIA_FUENTE = "SansSerif"; // ← Cambiar por "Arial", "Segoe UI", etc.

// También en métodos individuales donde se define directamente:
new Font("SansSerif", Font.BOLD, 13)
// Cambiar a:
new Font("Segoe UI", Font.BOLD, 13)
```

### Cambiar colores de los componentes del FrmLogin (diseño visual)

Los componentes del login se configuran en el archivo `FrmLogin.form` (editor visual de NetBeans) y en el método `initComponents()` del `FrmLogin.java`.

Para cambiar el color del botón login:
```java
// En initComponents(), buscar:
btnLogin.setBackground(new java.awt.Color(253, 155, 170)); // Rosa

// Cambiar los valores RGB:
btnLogin.setBackground(new java.awt.Color(66, 133, 244)); // Azul Google
```

Para cambiar el efecto hover del botón (cuando el ratón pasa por encima):
```java
private void btnLoginMouseEntered(java.awt.event.MouseEvent evt) {
    btnLogin.setBackground(Color.PINK); // ← Cambiar aquí
}

private void btnLoginMouseExited(java.awt.event.MouseEvent evt) {
    btnLogin.setBackground(new Color(253, 155, 170)); // ← Cambiar aquí (color normal)
}
```

### Cambiar el badge de estado de las tarjetas de pedido (PDF)

En `ReportePDF.java`, los colores están definidos como constantes al inicio:
```java
private static final Color ROSA       = new Color(255, 102, 153);
private static final Color FONDO_PENDIENTE = new Color(250, 238, 218);
private static final Color BORDE_PENDIENTE = new Color(239, 159, 39);
private static final Color FONDO_COBRADO   = new Color(234, 243, 222);
// etc.
```

---

## 16. Flujo completo de ejecución

```
1. El usuario ejecuta la aplicación
   → FrmLogin.main() → new FrmLogin().setVisible(true)

2. El usuario ingresa usuario y contraseña, hace clic en "Iniciar Sesión"
   → FrmLogin llama a controlador.manejarLogin()
   → ControladorFrmLogin crea un SwingWorker
   → El SwingWorker llama a autenticacion.obtenerAdministradorAutenticado()
   → SistemaAutenticacion busca el admin por nombre en la BD
   → Compara el hash SHA-256 de la contraseña ingresada con el hash guardado
   → Si coincide: devuelve el objeto Administrador

3. Login exitoso
   → FrmLogin.dispose() (se cierra)
   → new FrmDashboard(administrador).setVisible(true)

4. FrmDashboard se construye
   → initComponents() crea la estructura básica (tabs vacías)
   → Se instancian repositorios JPA (ClienteJpaController, etc.)
   → Se instancia PedidoService con los repositorios
   → Se instancia ControladorDashboard con el servicio y referencias a los paneles
   → controlador.inicializar():
       a. repoEtiqueta.inicializarPorDefecto() → si la tabla está vacía, inserta tipos/estilos/tallas por defecto
       b. tabPedidosCtrl.construir() → construye el formulario de la pestaña "+ Pedidos"
       c. setupTabTodos() → construye la pestaña "Todos"
       d. setupTabClientes() → construye la pestaña "Clientes"
       e. setupTabReporte() → construye la pestaña "Reporte"
       f. setupTabConfiguraciones() → construye la pestaña "Configuraciones"
       g. setupTabConfigurarPassword() → construye la pestaña de credenciales
       h. actualizarContadores() → consulta BD y muestra números en la barra superior

5. El administrador agrega un producto
   → ControladorTabPedidos.onAgregarProducto()
   → Valida campos del formulario
   → Llama a servicioPedido.agregarProducto(...)
   → PedidoService: busca/crea cliente → busca/crea pedido pendiente → crea producto
   → Guarda en BD mediante repositorios JPA
   → servicioPedido.notificarObservadores()
   → ControladorDashboard.actualizar() → refrescarTodo()
   → La interfaz se actualiza: los contadores y listas muestran los nuevos datos

6. El admin marca un pedido como cobrado
   → ControladorDashboard.onMarcarCobrado(pedidoId)
   → servicioPedido.marcarCobrado(pedidoId)
   → Pedido.setEstado("COBRADO"), setPedido.setFechaCobro(ahora)
   → repoPedido.editar(pedido) → Hibernate genera UPDATE
   → notificarObservadores() → la interfaz se refresca

7. El admin exporta un reporte PDF
   → ControladorDashboard llama a ReportePDF.generarReportePedidos(...)
   → Se abre JFileChooser para elegir destino
   → OpenPDF construye el documento
   → Se guarda el archivo y se ofrece abrirlo
```

---

## 17. Guía de modificaciones frecuentes

### Agregar un nuevo tipo de etiqueta (categoría)

Las categorías predeterminadas se inicializan en `EtiquetaConfigJpaController.inicializarPorDefecto()`:

```java
String[] tipos   = {"Ropa", "Bolso", "Accesorio", "Zapatos"};
// Para agregar "Joyería":
String[] tipos   = {"Ropa", "Bolso", "Accesorio", "Zapatos", "Joyería"};
```

Esto solo aplica la primera vez que se levanta la aplicación con la tabla vacía. Si la tabla ya tiene datos, se deben agregar desde la pestaña "Configuraciones" de la interfaz.

### Cambiar el puerto de la base de datos

En `persistence.xml`:
```xml
<property name="jakarta.persistence.jdbc.url"
          value="jdbc:postgresql://localhost:5433/postgres"/>
                                               ^^^^
                                          Cambiar aquí
```

### Agregar un nuevo campo a un formulario

Ejemplo: agregar campo "color" al formulario de producto.

1. Agregar atributo en `model/Producto.java`:
   ```java
   @Column(length = 100)
   private String color;
   ```

2. Agregar línea en `persistence.xml` (si la clase no estaba ya listada — en este caso sí está).

3. Hibernate creará la columna automáticamente (`hbm2ddl.auto = update`).

4. En `controller/ControladorTabPedidos.java`, agregar el campo al formulario:
   ```java
   private JTextField txtColor;
   // En construirFormulario():
   txtColor = new JTextField();
   aplicarMarcador(txtColor, "Color (opcional)");
   ```

5. En `onAgregarProducto()`, leer el campo y pasarlo al servicio:
   ```java
   String color = leerCampo(txtColor);
   // Pasarlo como atributo extra o como campo del Producto
   ```

### Cambiar el límite máximo de intentos de login

En `ControladorFrmLogin.java`:
```java
private static final int MAX_INTENTOS = 3; // ← Cambiar aquí
```

### Ver el SQL generado por Hibernate (depuración)

Ya está activado en `persistence.xml`:
```xml
<property name="hibernate.show_sql" value="true"/>
<property name="hibernate.format_sql" value="true"/>
```
El SQL aparece en la consola (Output de NetBeans) al ejecutar la aplicación.

Para desactivarlo en producción, cambiar `"true"` por `"false"`.

### Crear un nuevo administrador desde cero

Ejecutar `utils/CrearAdministradorPrueba.java` como clase principal (clic derecho → Run File en NetBeans) después de editar las credenciales en las líneas:
```java
String correo     = "nuevo@admin.com";
String nombre     = "nuevoAdmin";
String contrasena = "miContraseña";
```

---

---

## 18. Ejemplos reales de modificaciones paso a paso

Esta sección muestra modificaciones concretas al proyecto, con el código **antes** y **después**, indicando exactamente en qué archivo y en qué parte hacer el cambio.

---

### Ejemplo 1 — Cambiar el color de todos los chips (rosa → morado)

**Qué se quiere lograr:** Los chips de tipo, estilo y talla actualmente son rosados. Se quieren cambiar a morado.

**Archivo a modificar:** `src/main/java/utils/EstiloUI.java`

**Paso 1 — Abrir el archivo en NetBeans**
Navegar en el árbol de proyectos: `Source Packages → utils → EstiloUI.java`

**Paso 2 — Buscar las paletas de color**
Al inicio del archivo, después de `public final class EstiloUI {`, están las constantes de paleta. Buscar el bloque que dice `PALETA_TIPO`.

**ANTES (líneas ~46 a ~72):**
```java
public static final Color[][] PALETA_TIPO = {
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
};

public static final Color[][] PALETA_ESTILO = {
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
};

public static final Color[][] PALETA_PRECIO = {
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
};
```

**DESPUÉS (reemplazar con colores morados):**
```java
// Fondo morado claro, texto morado oscuro, borde morado medio
public static final Color[][] PALETA_TIPO = {
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
};

public static final Color[][] PALETA_ESTILO = {
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
};

public static final Color[][] PALETA_PRECIO = {
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},
};
```

**Paso 3 — Guardar y recompilar**
Pulsar `Ctrl+S` en NetBeans para guardar. Luego `Shift+F11` (Clean and Build) o `F6` (Run) para ver el resultado.

**Referencia de colores hexadecimales morados útiles:**
| Hex | Descripción |
|---|---|
| `F0E6FF` | Morado muy claro (para fondo) |
| `3B0066` | Morado muy oscuro (para texto) |
| `8B3DCC` | Morado medio (para borde) |
| `6A0DAD` | Morado puro (alternativa para borde) |
| `E8D5FF` | Lavanda (fondo alternativo) |

> **Nota:** El formato de cada fila del array es `{color_fondo, color_texto, color_borde}`. Los tres valores son obligatorios.

---

### Ejemplo 2 — Dar a cada tipo de chip un color diferente (paleta multicolor)

**Qué se quiere lograr:** En vez de que todos los chips de "Tipo" sean del mismo color, que "Ropa" sea azul, "Bolso" sea verde, "Accesorio" sea naranja y "Zapatos" sea morado.

**Archivo a modificar:** `src/main/java/utils/EstiloUI.java`

**ANTES:**
```java
public static final Color[][] PALETA_TIPO = {
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
    {color("FCE8F2"), color("4A0A2C"), color("C93384")},
};
```

**DESPUÉS:**
```java
// Cada fila corresponde a una etiqueta de tipo en orden de aparición:
// índice 0 → "Ropa" (azul)
// índice 1 → "Bolso" (verde)
// índice 2 → "Accesorio" (naranja)
// índice 3 → "Zapatos" (morado)
// índice 4 → por si se agrega un 5to tipo (turquesa)
public static final Color[][] PALETA_TIPO = {
    {color("E3F0FB"), color("042C53"), color("378ADD")},  // Azul
    {color("EAF3DE"), color("173404"), color("639922")},  // Verde
    {color("FFF3E0"), color("4A2000"), color("F57C00")},  // Naranja
    {color("F0E6FF"), color("3B0066"), color("8B3DCC")},  // Morado
    {color("E0F7FA"), color("004D40"), color("00897B")},  // Turquesa
};
```

**¿Cómo funciona la asignación?**
En `ControladorTabPedidos.java`, método `construirChipsTipo()`:
```java
for (int i = 0; i < tipos.size(); i++) {
    final String valor = tipos.get(i).getValor();
    Color[] colores = EstiloUI.PALETA_TIPO[i % EstiloUI.PALETA_TIPO.length];
    // i=0 → colores[0] (Azul)
    // i=1 → colores[1] (Verde)
    // i=2 → colores[2] (Naranja)
    // Si hay más tipos que filas en la paleta, se repite cíclicamente (% length)
    JToggleButton chip = EstiloUI.crearChip(valor, colores);
```

---

### Ejemplo 3 — Cambiar el nombre y color del botón de login

**Qué se quiere lograr:** El botón dice "Iniciar Sesion" y es rosado. Cambiarlo a "Entrar al sistema" y color azul.

**Archivo a modificar:** `src/main/java/view/FrmLogin.java`

> **IMPORTANTE:** El texto del botón está en el bloque `//GEN-BEGIN`/`//GEN-END` que NetBeans regenera. Se debe cambiar **a través del editor visual** del `.form`, no directamente en el Java. El color en cambio sí se puede editar fuera del bloque.

**Paso 1 — Cambiar el texto del botón (vía editor visual de NetBeans)**
1. Abrir `FrmLogin.form` (doble clic en NetBeans — abre el diseñador visual).
2. Hacer clic sobre el botón "Iniciar Sesion" en el diseñador.
3. En el panel "Properties" (propiedades) a la derecha, buscar el campo `text`.
4. Cambiar `"Iniciar Sesion"` por `"Entrar al sistema"`.
5. Guardar (`Ctrl+S`). NetBeans regenerará automáticamente el método `initComponents()`.

**Paso 2 — Cambiar el color de fondo del botón**
En el mismo editor visual, con el botón seleccionado:
1. En "Properties", buscar `background`.
2. Hacer clic en el cuadro de color.
3. Ingresar los valores RGB: R=66, G=133, B=244 (azul).
4. Guardar.

**Alternativamente, editar el código fuera del bloque GEN:**
Buscar en `FrmLogin.java` los métodos `btnLoginMouseEntered` y `btnLoginMouseExited` (están **fuera** del bloque `//GEN-BEGIN`):

**ANTES:**
```java
private void btnLoginMouseEntered(java.awt.event.MouseEvent evt) {
    btnLogin.setBackground(Color.PINK);
}

private void btnLoginMouseExited(java.awt.event.MouseEvent evt) {
    btnLogin.setBackground(new Color(253, 155, 170));
}
```

**DESPUÉS (colores azules para hover):**
```java
private void btnLoginMouseEntered(java.awt.event.MouseEvent evt) {
    btnLogin.setBackground(new Color(30, 100, 200));   // Azul más oscuro al pasar el ratón
}

private void btnLoginMouseExited(java.awt.event.MouseEvent evt) {
    btnLogin.setBackground(new Color(66, 133, 244));   // Azul normal
}
```

---

### Ejemplo 4 — Cambiar el nombre "Pinky Puff" del login por otro nombre

**Qué se quiere lograr:** El título "Pinky Puff" en la pantalla de login debe llamarse "Mi Tienda".

**Archivo a modificar:** `src/main/java/view/FrmLogin.java` (vía editor visual del `.form`)

**Paso 1 — Abrir el diseñador**
Doble clic en `FrmLogin.form` en NetBeans.

**Paso 2 — Identificar los labels del título**
El título "Pinky Puff" está formado por **dos** labels separados:
- `LblUsuario1` → contiene el texto `"Pinky"` (color negro)
- `jLabel1` → contiene el texto `"Puff"` (color rosado `#FD899B`)

Hacer clic en cada uno en el diseñador visual.

**Paso 3 — Cambiar el texto**
En "Properties" de cada label, cambiar el campo `text`:
- `LblUsuario1.text` → de `"Pinky"` a `"Mi"`
- `jLabel1.text` → de `"Puff"` a `"Tienda"`

**Paso 4 — (Opcional) Cambiar el color de la segunda palabra**
Con `jLabel1` seleccionado, en "Properties" → `foreground`:
Cambiar el color rosado por el que se prefiera.

**Paso 5 — Guardar**
`Ctrl+S`. El archivo `.java` se actualiza automáticamente.

**Cambiar también el nombre en el PDF generado:**
En `src/main/java/controller/ReportePDF.java`, método `crearEncabezado()`:

**ANTES:**
```java
Paragraph pNombre = new Paragraph("PinkyPuff", F_HEADER_TITULO);
```

**DESPUÉS:**
```java
Paragraph pNombre = new Paragraph("Mi Tienda", F_HEADER_TITULO);
```

Y en `eventoPieDePagina()`:

**ANTES:**
```java
Phrase pie = new Phrase(
    "PinkyPuff  ·  Pagina " + w.getPageNumber(), F_PIE);
```

**DESPUÉS:**
```java
Phrase pie = new Phrase(
    "Mi Tienda  ·  Pagina " + w.getPageNumber(), F_PIE);
```

---

### Ejemplo 5 — Cambiar el nombre de una pestaña del dashboard

**Qué se quiere lograr:** La pestaña `"+ Pedidos"` se quiere llamar `"Nuevo Pedido"`.

**Archivo a modificar:** `src/main/java/view/FrmDashboard.java` (vía editor visual)

**Paso 1 — Abrir el diseñador**
Doble clic en `FrmDashboard.form` en NetBeans.

**Paso 2 — Seleccionar el JTabbedPane**
Hacer clic sobre cualquier pestaña del panel de pestañas en el diseñador visual. Verás el componente `tabPrincipal` seleccionado.

**Paso 3 — Editar el título de la pestaña**
En el panel "Properties":
1. Buscar la propiedad `tabTitleAt` o hacer clic derecho sobre la pestaña → "Edit Tab Title".
2. Cambiar `"+ Pedidos"` por `"Nuevo Pedido"`.

**Alternativa directa en código** (buscar en `initComponents()`, pero NO editar el bloque GEN):
La línea está dentro del bloque generado. La forma segura es siempre el editor visual.

**Verificación:** Después de guardar el `.form`, buscar en `FrmDashboard.java` el bloque generado:
```java
// ANTES (generado por NetBeans):
tabPrincipal.addTab("+ Pedidos", tabPedidos);

// DESPUÉS (lo que genera NetBeans tras el cambio en el .form):
tabPrincipal.addTab("Nuevo Pedido", tabPedidos);
```

---

### Ejemplo 6 — Cambiar el color de la barra de contadores superior del dashboard

**Qué se quiere lograr:** El panel superior con "Pendientes / Por cobrar / Cobrados hoy" tiene fondo blanco y borde gris. Cambiarlo a fondo rosado claro.

**Archivo a modificar:** `src/main/java/view/FrmDashboard.java` (vía editor visual)

**Paso 1 — Abrir el diseñador de `FrmDashboard.form`**

**Paso 2 — Seleccionar el panel `jPanel3`**
Es el panel en la parte superior que contiene los tres contadores. Hacer clic sobre él.

**Paso 3 — Cambiar el color de fondo**
En "Properties" → `background` → elegir el color deseado.
- Para rosado claro: R=255, G=220, B=235 (hex: `FFDCEB`)

**Paso 4 — (Opcional) Cambiar el color de los números**
Los labels `lblContadorPendientes`, `lblContadorPorCobrar`, `lblContadorCobradosHoy` tienen el color `(255, 102, 153)` rosado fuerte. Para cambiarlos a otro color, seleccionar cada label en el diseñador y modificar `foreground`.

---

### Ejemplo 7 — Cambiar el color de las tarjetas de pedido según estado

**Qué se quiere lograr:** Las tarjetas de pedido "PENDIENTE" son amarillas. Cambiarlas a azul claro.

**Archivo a modificar:** `src/main/java/controller/ControladorDashboard.java`

**Paso 1 — Abrir el archivo**
`Source Packages → controller → ControladorDashboard.java`

**Paso 2 — Buscar el método `crearTarjetaPedido`**
Usar `Ctrl+F` en NetBeans y buscar `crearTarjetaPedido`.

**Paso 3 — Localizar y modificar los colores**

**ANTES (aprox. línea 634):**
```java
private JPanel crearTarjetaPedido(Pedido pedido) {
    String estado = pedido.getEstado();
    Color colorFondo = "PENDIENTE".equals(estado) ? c("FAEEDA")
        : "COBRADO".equals(estado) ? c("EAF3DE") : c("F1EFE8");
    Color colorBorde = "PENDIENTE".equals(estado) ? c("EF9F27")
        : "COBRADO".equals(estado) ? c("639922") : c("888780");
```

**DESPUÉS (azul claro para PENDIENTE):**
```java
private JPanel crearTarjetaPedido(Pedido pedido) {
    String estado = pedido.getEstado();
    Color colorFondo = "PENDIENTE".equals(estado) ? c("E3F0FB")   // Azul claro
        : "COBRADO".equals(estado) ? c("EAF3DE") : c("F1EFE8");
    Color colorBorde = "PENDIENTE".equals(estado) ? c("378ADD")   // Azul borde
        : "COBRADO".equals(estado) ? c("639922") : c("888780");
```

**Paso 4 — Cambiar también el badge de estado dentro de la misma tarjeta**
Buscar más abajo en el mismo método la parte que define `coloresEstado`:

**ANTES:**
```java
Color[] coloresEstado = "PENDIENTE".equals(estado)
    ? new Color[]{c("FAEEDA"), c("633806")}
    : "COBRADO".equals(estado)
        ? new Color[]{c("EAF3DE"), c("173404")}
        : new Color[]{c("F1EFE8"), c("444444")};
```

**DESPUÉS:**
```java
Color[] coloresEstado = "PENDIENTE".equals(estado)
    ? new Color[]{c("E3F0FB"), c("042C53")}   // Azul fondo, azul oscuro texto
    : "COBRADO".equals(estado)
        ? new Color[]{c("EAF3DE"), c("173404")}
        : new Color[]{c("F1EFE8"), c("444444")};
```

**Paso 5 — Guardar (`Ctrl+S`) y ejecutar (`F6`)**

---

### Ejemplo 8 — Cambiar los valores de etiquetas por defecto (tipos, estilos, tallas)

**Qué se quiere lograr:** En vez de `"Ropa", "Bolso", "Accesorio", "Zapatos"` como tipos por defecto, usar `"Vestimenta", "Complementos", "Bisutería", "Calzado"`.

**Archivo a modificar:** `src/main/java/persistencia/EtiquetaConfigJpaController.java`

**Paso 1 — Abrir el archivo**
`Source Packages → persistencia → EtiquetaConfigJpaController.java`

**Paso 2 — Buscar el método `inicializarPorDefecto`**
Usar `Ctrl+F` y buscar `inicializarPorDefecto`.

**ANTES (aprox. línea 68):**
```java
public void inicializarPorDefecto() {
    // ... (verificación de tabla vacía) ...

    String[] tipos   = {"Ropa", "Bolso", "Accesorio", "Zapatos"};
    String[] estilos = {"Casual", "Formal", "Deportivo", "Bohemio",
                        "Elegante", "Vintage", "Juvenil", "Básico"};
    String[] tallas  = {"XS", "S", "M", "L", "XL", "XXL"};
    Object[][] precios = {
        {"Liquidación", 1.0},
        {"Base",        2.5},
        {"Buen estado", 5.0},
        {"Premium",    10.0}
    };
```

**DESPUÉS:**
```java
public void inicializarPorDefecto() {
    // ... (verificación de tabla vacía) ...

    String[] tipos   = {"Vestimenta", "Complementos", "Bisutería", "Calzado"};
    String[] estilos = {"Casual", "Formal", "Deportivo", "Romántico",
                        "Elegante", "Vintage", "Urbano", "Clásico"};
    String[] tallas  = {"Única", "XS", "S", "M", "L", "XL"};
    Object[][] precios = {
        {"Oferta",     0.5},
        {"Normal",     3.0},
        {"Buen estado",6.0},
        {"Premium",   15.0}
    };
```

> **ADVERTENCIA:** Este método solo se ejecuta si la tabla `etiquetas_config` está **completamente vacía**. Si la aplicación ya tiene datos, este cambio no tendrá efecto. En ese caso, borrar las etiquetas desde la pestaña "Configuraciones" de la interfaz y luego reiniciar la app, o borrar directamente la tabla en PostgreSQL:
> ```sql
> DELETE FROM etiquetas_config;
> ```

---

### Ejemplo 9 — Cambiar el color del botón principal "Agregar producto"

**Qué se quiere lograr:** El botón "Agregar producto" en la pestaña `+ Pedidos` es rosado `(253, 155, 170)`. Cambiarlo a verde.

**Archivo a modificar:** `src/main/java/controller/ControladorTabPedidos.java`

**Paso 1 — Abrir el archivo**
`Source Packages → controller → ControladorTabPedidos.java`

**Paso 2 — Buscar la definición del botón**
Usar `Ctrl+F` y buscar `Agregar producto`. La línea está en el método `construir()`.

**ANTES (aprox. línea 127):**
```java
JButton btnAgregar = new JButton("Agregar producto");
btnAgregar.setAlignmentX(Component.LEFT_ALIGNMENT);
btnAgregar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
btnAgregar.setBackground(new Color(253, 155, 170));   // Rosa
btnAgregar.setForeground(Color.WHITE);
btnAgregar.setFont(btnAgregar.getFont().deriveFont(Font.BOLD, 13f));
btnAgregar.setFocusPainted(false);
btnAgregar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
```

**DESPUÉS (verde):**
```java
JButton btnAgregar = new JButton("Agregar producto");
btnAgregar.setAlignmentX(Component.LEFT_ALIGNMENT);
btnAgregar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
btnAgregar.setBackground(new Color(76, 175, 80));     // Verde Material Design
btnAgregar.setForeground(Color.WHITE);
btnAgregar.setFont(btnAgregar.getFont().deriveFont(Font.BOLD, 13f));
btnAgregar.setFocusPainted(false);
btnAgregar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
```

**Paso 3 — Guardar y ejecutar**

---

### Ejemplo 10 — Cambiar los colores de estado de los clientes

**Qué se quiere lograr:** El estado `"BLOQUEADO"` actualmente es rojo. Cambiarlo a naranja para que sea menos alarmante.

**Archivo a modificar:** `src/main/java/utils/EstiloUI.java`

**Paso 1 — Buscar las constantes de estado**
Al inicio de `EstiloUI.java`, buscar `COLORES_ESTADO_BLOQUEADO`.

**ANTES (aprox. línea 76):**
```java
public static final Color[] COLORES_ESTADO_BLOQUEADO = {color("FCEBEB"), color("791F1F"), color("F09595")};
// Fondo: rojo muy claro | Texto: rojo oscuro | Borde: rojo medio
```

**DESPUÉS (naranja):**
```java
public static final Color[] COLORES_ESTADO_BLOQUEADO = {color("FFF3E0"), color("4A2000"), color("F57C00")};
// Fondo: naranja muy claro | Texto: naranja oscuro | Borde: naranja
```

**Paso 2 — Verificar que el cambio aplica en todos los lugares**
Este array se usa en tres lugares:
1. Las tarjetas de cliente (badge de estado y borde de tarjeta).
2. Los filtros de estado en la pestaña "Clientes" (los chips de filtro).
3. El botón "Estado" en la tarjeta de cliente.

Al cambiar la constante en `EstiloUI.java`, todos estos lugares se actualizan automáticamente porque todos leen de la misma constante.

---

### Ejemplo 11 — Agregar una nueva pestaña al dashboard

**Qué se quiere lograr:** Agregar una nueva pestaña llamada "Inventario" al `JTabbedPane` del dashboard.

**Archivos a modificar:** `FrmDashboard.form` (visual) y `FrmDashboard.java` + `ControladorDashboard.java` (código).

**Paso 1 — Agregar la pestaña en el diseñador visual**
1. Abrir `FrmDashboard.form` en NetBeans.
2. Hacer clic derecho sobre el `JTabbedPane`.
3. Seleccionar "Add Tab" → aparecerá una nueva pestaña.
4. Con la nueva pestaña seleccionada, en "Properties" cambiar el nombre del componente a `tabInventario` (en el campo `variable name`).
5. En la propiedad de la pestaña, cambiar el título a `"Inventario"`.
6. Guardar (`Ctrl+S`).

NetBeans agrega automáticamente en `initComponents()`:
```java
tabInventario = new javax.swing.JPanel();
// ...
tabPrincipal.addTab("Inventario", tabInventario);
```

Y en la sección de declaración de variables:
```java
private javax.swing.JPanel tabInventario;
```

**Paso 2 — Exponer el nuevo panel al controlador**
En `FrmDashboard.java`, en el constructor:

**ANTES:**
```java
controlador = new ControladorDashboard(
    administrador,
    servicioPedido, repoEtiqueta, repoAdmin,
    tabPedidos, tabTodosPedidos,
    tabClientes, tabReporte, tabConfiguraciones,
    tabConfigurarPassword,
    lblContadorPendientes, lblContadorPorCobrar, lblContadorCobradosHoy
);
```

**DESPUÉS:**
```java
controlador = new ControladorDashboard(
    administrador,
    servicioPedido, repoEtiqueta, repoAdmin,
    tabPedidos, tabTodosPedidos,
    tabClientes, tabReporte, tabConfiguraciones,
    tabConfigurarPassword,
    tabInventario,                          // ← NUEVO
    lblContadorPendientes, lblContadorPorCobrar, lblContadorCobradosHoy
);
```

**Paso 3 — Actualizar el constructor de `ControladorDashboard`**
En `ControladorDashboard.java`:

Agregar el campo:
```java
private final JPanel tabInventario;   // ← NUEVO campo
```

Agregar el parámetro al constructor:
```java
public ControladorDashboard(
        ...
        JPanel tabConfigurarPassword,
        JPanel tabInventario,           // ← NUEVO parámetro
        JLabel lblContPendientes, ...) {
    ...
    this.tabInventario = tabInventario; // ← NUEVA asignación
    ...
}
```

**Paso 4 — Crear el método que construye la pestaña**
En `ControladorDashboard.java`, agregar:
```java
private void setupTabInventario() {
    tabInventario.removeAll();
    tabInventario.setLayout(new BorderLayout());

    JPanel contenido = new JPanel();
    contenido.setLayout(new BoxLayout(contenido, BoxLayout.Y_AXIS));
    contenido.setBorder(new EmptyBorder(16, 16, 16, 16));

    JLabel titulo = EstiloUI.crearSeccionLabel("Inventario de productos");
    contenido.add(titulo);
    contenido.add(Box.createVerticalStrut(12));

    // Aquí se puede agregar una tabla JTable o lista de productos
    JLabel placeholder = EstiloUI.crearMensajeVacio("Funcionalidad en construcción");
    contenido.add(placeholder);

    JScrollPane scroll = new JScrollPane(contenido);
    scroll.setBorder(null);
    tabInventario.add(scroll, BorderLayout.CENTER);
    tabInventario.revalidate();
}
```

**Paso 5 — Llamar al método desde `inicializar()`**
En el método `inicializar()`:

**ANTES:**
```java
public void inicializar() {
    repoEtiqueta.inicializarPorDefecto();
    tabPedidosCtrl.construir();
    setupTabTodos();
    setupTabClientes();
    setupTabReporte();
    setupTabConfiguraciones();
    setupTabConfigurarPassword();
    actualizarContadores();
}
```

**DESPUÉS:**
```java
public void inicializar() {
    repoEtiqueta.inicializarPorDefecto();
    tabPedidosCtrl.construir();
    setupTabTodos();
    setupTabClientes();
    setupTabReporte();
    setupTabConfiguraciones();
    setupTabConfigurarPassword();
    setupTabInventario();       // ← NUEVA LLAMADA
    actualizarContadores();
}
```

---

### Ejemplo 12 — Cambiar el tamaño de fuente de los contadores superiores

**Qué se quiere lograr:** Los números de "Pendientes", "Por cobrar" y "Cobrados hoy" tienen fuente de tamaño 24. Aumentarlos a tamaño 32 para que se vean más grandes.

**Archivo a modificar:** `src/main/java/view/FrmDashboard.java` (vía editor visual)

**Paso 1 — Abrir el diseñador de `FrmDashboard.form`**

**Paso 2 — Seleccionar el label `lblContadorPendientes`**
Hacer clic sobre el número "0" que está junto a "Pendientes".

**Paso 3 — Cambiar la fuente**
En "Properties" → `font` → hacer clic en el botón "..." para abrir el selector de fuente.
Cambiar el tamaño de `24` a `32`.

**Repetir para `lblContadorPorCobrar` y `lblContadorCobradosHoy`.**

**Paso 4 — Guardar**

El código generado en `initComponents()` pasará de:
```java
lblContadorPendientes.setFont(new java.awt.Font("Adwaita Sans", 1, 24));
```
a:
```java
lblContadorPendientes.setFont(new java.awt.Font("Adwaita Sans", 1, 32));
```

---

### Ejemplo 13 — Cambiar el texto del placeholder de los campos del formulario

**Qué se quiere lograr:** El campo de cliente dice `"Nombre del cliente"`. Cambiarlo a `"Nombre o alias del cliente"`.

**Archivo a modificar:** `src/main/java/controller/ControladorTabPedidos.java`

**Paso 1 — Abrir el archivo**

**Paso 2 — Buscar el método `construirFormulario`**
Usar `Ctrl+F` y buscar `construirFormulario`.

**ANTES (aprox. línea 327):**
```java
txtCliente = new JTextField();
aplicarMarcador(txtCliente, "Nombre del cliente");
```

**DESPUÉS:**
```java
txtCliente = new JTextField();
aplicarMarcador(txtCliente, "Nombre o alias del cliente");
```

**Otros placeholders en el mismo método:**
```java
// ANTES:
aplicarMarcador(txtPrecio, "0.00");
aplicarMarcador(txtDescripcion, "Descripción opcional");
aplicarMarcador(txtCantidad, "1");

// DESPUÉS (más descriptivos):
aplicarMarcador(txtPrecio, "Ej: 15.50");
aplicarMarcador(txtDescripcion, "Detalles adicionales...");
aplicarMarcador(txtCantidad, "Cant. (default 1)");
```

**Paso 3 — Guardar y ejecutar**

---

### Ejemplo 14 — Cambiar el color rosa del encabezado en los PDFs

**Qué se quiere lograr:** La banda superior del PDF que dice "PinkyPuff" es rosa `(255, 102, 153)`. Cambiarlo a azul marino.

**Archivo a modificar:** `src/main/java/controller/ReportePDF.java`

**Paso 1 — Abrir el archivo**
`Source Packages → controller → ReportePDF.java`

**Paso 2 — Buscar la constante `ROSA`**
Al inicio del archivo, dentro de la clase:

**ANTES:**
```java
private static final Color ROSA       = new Color(255, 102, 153);
private static final Color ROSA_CLARO = new Color(255, 220, 235);
```

**DESPUÉS:**
```java
private static final Color ROSA       = new Color(26, 82, 145);    // Azul marino
private static final Color ROSA_CLARO = new Color(187, 210, 235);  // Azul claro
```

**Paso 3 — Verificar las fuentes que usan estos colores**
Más abajo en el mismo archivo, las fuentes de texto usan `ROSA` y `ROSA_CLARO`:
```java
private static final Font F_HEADER_TITULO = new Font(Font.HELVETICA, 22, Font.BOLD,   Color.WHITE);
private static final Font F_HEADER_SUB    = new Font(Font.HELVETICA, 12, Font.NORMAL, Color.WHITE);
private static final Font F_HEADER_FECHA  = new Font(Font.HELVETICA,  9, Font.ITALIC, ROSA_CLARO); // ← usa ROSA_CLARO
private static final Font F_SECCION       = new Font(Font.HELVETICA, 11, Font.BOLD,   ROSA);       // ← usa ROSA
private static final Font F_STAT_VALOR    = new Font(Font.HELVETICA, 15, Font.BOLD,   ROSA);       // ← usa ROSA
```

Al cambiar las constantes `ROSA` y `ROSA_CLARO`, todos estos textos del PDF cambian de color automáticamente.

**Paso 4 — Guardar y probar**
Ejecutar la app y exportar un PDF desde la pestaña "Reporte" para ver el resultado.

---

### Ejemplo 15 — Cambiar el máximo de intentos de login de 3 a 5

**Qué se quiere lograr:** Actualmente la aplicación bloquea tras 3 intentos fallidos. Aumentarlo a 5.

**Archivo a modificar:** `src/main/java/controller/ControladorFrmLogin.java`

**Paso 1 — Abrir el archivo**
`Source Packages → controller → ControladorFrmLogin.java`

**Paso 2 — Buscar la constante al inicio de la clase**

**ANTES:**
```java
public class ControladorFrmLogin {

    private static final int MAX_INTENTOS = 3;
```

**DESPUÉS:**
```java
public class ControladorFrmLogin {

    private static final int MAX_INTENTOS = 5;
```

**Paso 3 — Verificar el mensaje de error**
Más abajo en el método `manejarLogin()`, el mensaje ya usa la constante dinámicamente:
```java
int intentosRestantes = MAX_INTENTOS - intentosFallidos;
// ...
JOptionPane.showMessageDialog(vista,
    "Usuario o contraseña incorrectos. Le quedan " + intentosRestantes + " intento(s).",
    "Acceso denegado", JOptionPane.ERROR_MESSAGE);
```
No hay que cambiar nada más; el mensaje se actualiza solo porque usa `MAX_INTENTOS`.

---

### Resumen de archivos y sus responsabilidades de modificación

| Qué quiero cambiar | Archivo a modificar |
|---|---|
| Colores de chips (tipo, estilo, talla, precio) | `utils/EstiloUI.java` → constantes `PALETA_*` |
| Colores de estado de clientes (Activo/Inactivo/Bloqueado) | `utils/EstiloUI.java` → constantes `COLORES_ESTADO_*` |
| Colores de tarjetas de pedido | `controller/ControladorDashboard.java` → método `crearTarjetaPedido()` |
| Texto del botón de login | `view/FrmLogin.form` (editor visual NetBeans) |
| Color del botón de login | `view/FrmLogin.form` o `view/FrmLogin.java` métodos `btnLoginMouseEntered/Exited` |
| Nombre de la app ("PinkyPuff") en el login | `view/FrmLogin.form` (labels `LblUsuario1` y `jLabel1`) |
| Nombre de la app en los PDFs | `controller/ReportePDF.java` → método `crearEncabezado()` y `eventoPieDePagina()` |
| Nombres de las pestañas del dashboard | `view/FrmDashboard.form` (editor visual NetBeans) |
| Color de fondo del panel de contadores | `view/FrmDashboard.form` (propiedad `background` del `jPanel3`) |
| Tamaño de fuente de los contadores | `view/FrmDashboard.form` (propiedad `font` de `lblContador*`) |
| Placeholders de los campos del formulario | `controller/ControladorTabPedidos.java` → método `construirFormulario()` |
| Color del botón "Agregar producto" | `controller/ControladorTabPedidos.java` → método `construir()` |
| Color del encabezado del PDF (banda rosa) | `controller/ReportePDF.java` → constantes `ROSA` y `ROSA_CLARO` |
| Etiquetas por defecto (tipos/estilos/tallas) | `persistencia/EtiquetaConfigJpaController.java` → `inicializarPorDefecto()` |
| Máximo de intentos de login | `controller/ControladorFrmLogin.java` → constante `MAX_INTENTOS` |
| Agregar una nueva pestaña | `view/FrmDashboard.form` + `FrmDashboard.java` + `ControladorDashboard.java` |

---

*Documento generado el 17 de junio de 2026 a partir del análisis completo del código fuente del proyecto PinkyPuff.*
